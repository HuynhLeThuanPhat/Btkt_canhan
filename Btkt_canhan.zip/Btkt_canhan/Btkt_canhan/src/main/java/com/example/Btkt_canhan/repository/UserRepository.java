package com.example.Btkt_canhan.repository;

import com.example.Btkt_canhan.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
