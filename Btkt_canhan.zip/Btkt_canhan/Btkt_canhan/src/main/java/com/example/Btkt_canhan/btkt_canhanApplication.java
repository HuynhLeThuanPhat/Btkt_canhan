package com.example.Btkt_canhan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class btkt_canhanApplication {

	public static void main(String[] args) {
		SpringApplication.run(btkt_canhanApplication.class, args);
	}

}
